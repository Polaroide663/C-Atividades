﻿class Atividade08
{
    public static void Main()
    {
        Console.Write("Digite o valor de a:");
        int a = int.Parse(Console.ReadLine());
        Console.Write("Digite o valor de b: ");
        int b = int.Parse(Console.ReadLine());
        Console.Write("Digite o valor de c:");
        int c = int.Parse(Console.ReadLine());

        double delta = b * b - 4 * a * c;

        if (delta < 0)
            Console.WriteLine("A equação não possui raizes real.");
        else if (delta == 0)
            Console.WriteLine("A equação possui um raiz real.");
        else
            Console.WriteLine("A equação possui duas raizes reais.");
    }
}