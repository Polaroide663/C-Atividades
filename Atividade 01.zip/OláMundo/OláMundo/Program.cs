﻿using System;
class Atividade01 
{
    public static void Main()
    {
        Console.WriteLine("Olá Mundo!");
        Console.Write("Qual é o seu nome? : ");
        string nome = Console.ReadLine();

        Console.Write("Digite o ano de seu nascimento: ");
        int ano = int.Parse(Console.ReadLine());

        int calculo = 2050 - ano;
        Console.WriteLine("Bom dia " + nome + " Sua idade em 2050 é: " + calculo);
    }
}