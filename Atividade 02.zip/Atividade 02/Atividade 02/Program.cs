﻿class Atividade02
{
    public static void Main()
    {
        Console.Write("Escreva um numero: ");
        int n1 = int.Parse(Console.ReadLine());
        Console.Write("Escreva outro numero: ");
        int n2 = int.Parse(Console.ReadLine());

        int soma = n1 + n2;
        int sub = n1 - n2;
        float divisão = n1 / n2;
        int mult = n1 * n2;

        Console.WriteLine("A soma dos números: " + soma);
        Console.WriteLine("A subtração dos números: " + sub);
        Console.WriteLine("A divisão dos números: " + divisão);
        Console.WriteLine("A multiplicação dos números: " + mult);
    }
}