﻿class Atividade03
{
    public static void Main()
    {
        Console.Write("Escreva o salario do funcionario: ");
        int salario = int.Parse(Console.ReadLine());

        double gra = 0.05 * salario;
        double desc = 0.07 * salario;

        double salarioF = (salario + gra) - desc;

        Console.WriteLine("O salário final do funcionário: " + salarioF);
    }
}