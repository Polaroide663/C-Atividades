﻿class AtividadeIMC
{
    public static void Main()
    {
        Console.Write("Digite o seu nome:");
        string nome = Console.ReadLine();
        Console.Write("Digite seu sexo (M ou F):");
        string sexo = Console.ReadLine().ToUpper();
        Console.Write("Digite seu peso:");
        double peso = double.Parse(Console.ReadLine().Replace(',', '.'));
        Console.Write("Digite sua altura:");
        double altura = double.Parse(Console.ReadLine());

        double imc = peso / (altura * altura);

        if (sexo == "M")
        {
            if (imc < 20.7)
            {
                Console.WriteLine("Seu peso é abaixo do normal");
            }
            else if (imc < 26.4)
            {
                Console.WriteLine("Seu peso está normal");
            }
            else if (imc < 27.8)
            {
                Console.WriteLine("Seu peso é marginalmente acima do peso");
            }
            else if(imc < 31.1)
            {
                Console.WriteLine("Seu peso e acima do ideal");
            }
            else
            {
                Console.WriteLine("Você é obeso");
            }
        }
        else if (sexo == "F")
        {
            if (imc < 19.1)
                Console.WriteLine("Seu peso é abaixo do normal");
            else if (imc < 25.8)
                Console.WriteLine("Seu peso está normal");
            else if (imc < 27.3)
                Console.WriteLine("Seu peso é marginalmente acima do peso");
            else if (imc < 32.3)
                Console.WriteLine("Seu peso é acima do ideal");
            else
                Console.WriteLine("Você é obesa");
        }
        else
        {
            Console.WriteLine("Sexo inválido. Digite M ou F.");
        }
    }
}