﻿class Atividade04
{
    public static void Main()
    {
        Console.Write("Escreva um valor: ");
        int n1 = int.Parse(Console.ReadLine());
        Console.Write("Escreva um segundo valor: ");
        int n2 = int.Parse(Console.ReadLine());
        Console.Write("Escreva um terceiro valor: ");
        int n3 = int.Parse(Console.ReadLine());

        int peso1 = n1 * 3;
        int peso2 = n2 * 3;
        int peso3 = n3 * 4;
        int result = (peso1 + peso2 + peso3) / 10;

        Console.WriteLine("O resultado é: " + result);


    }
}