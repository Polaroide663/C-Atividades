﻿class Atividade05
{
    public static void Main()
    {
        Console.Write("Escreva o valor em graus fahrenheit: ");
        int F = int.Parse(Console.ReadLine());

        double C = 5.0 / 9.0 * (F - 32);

        Console.WriteLine("A conversão para graus Celcius é: " + C);
    }
}