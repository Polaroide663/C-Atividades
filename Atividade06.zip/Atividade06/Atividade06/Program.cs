﻿class Atividade06
{
    public static void Main()
    {
        Console.Write("Digite um valor:");
        int valor = int.Parse(Console.ReadLine());

        if (valor > 0)
        {
            Console.WriteLine("O valor " + valor + " é positivo.");
        }
        else if (valor == 0)
        {
            Console.WriteLine("O valor " + valor + " é neutro.");
        }
        else
        {
            Console.WriteLine("O valor " + valor + " é negativo");
        }
    }
}