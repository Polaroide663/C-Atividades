﻿class Atividade07
{
    public static void Main()
    {
        Console.Write("Digite um valor: ");
        int n1 = int.Parse(Console.ReadLine());
        Console.Write("Digite o segundo valor: ");
        int n2 = int.Parse(Console.ReadLine());
        Console.Write("Digite o terceiro valor: ");
        int n3 = int.Parse(Console.ReadLine());

        double media = (n1 + n2 + n3) / 3;

        if(n1 > media)
        {
            Console.WriteLine("O valor " + n1 + " é maior que a media " + media);
        }
        else if (n2 > media)
        {
            Console.WriteLine("O valor " + n2 + " é maior que a media " + media);
        }
        else
        {
            Console.WriteLine("O valor " + n3 + " é maior que a media " + media);
        }
    }
}