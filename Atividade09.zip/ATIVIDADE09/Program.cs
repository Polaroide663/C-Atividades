﻿class Atividade09
{
    public static void Main()
    {
        Console.Write("Qual seu sexo ? M ou F");
        char sexo = char.Parse(Console.ReadLine().ToUpper());
        Console.Write("Digite sua altura:");
        double h = double.Parse(Console.ReadLine());

        double peso = (sexo == 'M') ? (72.7 * h - 58) : (62.1 * h - 44.7);
        Console.WriteLine($"O peso ideal é: {peso:F2} kg");
    }
}