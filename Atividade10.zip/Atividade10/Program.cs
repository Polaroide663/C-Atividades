﻿class Atividade10
{
    public static void Main()
    {
        Console.Write("Digite o nome do aluno:");
        string nome = (Console.ReadLine());
        Console.Write("Digite a primeira nota:");
        double n1 = double.Parse(Console.ReadLine());
        Console.Write("Digite a segunda nota:");
        double n2 = double.Parse(Console.ReadLine());
        Console.Write("Digite a terceira nota:");
        double n3 = double.Parse(Console.ReadLine());
        Console.Write("Digite o numero de faltas:");
        double faltas = double.Parse(Console.ReadLine());

       double media = (n1 + n2 + n3) /3;
        
        if(media < 5.0)
        {
            Console.WriteLine($"O Aluno está reprovado pela sua media: {media:F2}");
        }
        else if(faltas > 27)
        {
            Console.WriteLine("O aluno está reprovado pela sua quantidade de faltas: " + faltas);
        }
        else if(media < 5.0 && faltas > 27)
        {
            Console.WriteLine($"O aluno está reprovado pela sua media {media:F2}  " + "e sua quantidade de faltas " + faltas);
        } 
        else
        {
            Console.WriteLine($"O Aluno está aprovado, sua média é {media:F2} " + "e sua quantidade de faltas é " + faltas);
        }
    }
}