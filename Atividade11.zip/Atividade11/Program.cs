﻿class Atividade11
{
    public static void Main()
    {
        Console.Write("Digite o nome da primeira pessoa:");
        string nome1 = Console.ReadLine();
        Console.Write("Digite a idade da primeira pessoa:");
        int ida1 = int.Parse(Console.ReadLine());

        Console.Write("Digite o nome da segunda pessoa:");
        string nome2 = Console.ReadLine();
        Console.Write("Digite a idade da segunda pessoa:");
        int ida2 = int.Parse(Console.ReadLine());

        Console.Write("Digite o nome da terceira pessoa:");
        string nome3 = Console.ReadLine();
        Console.Write("Digite a idade da terceira pessoa:");
        int ida3 = int.Parse(Console.ReadLine());

        Console.Write("Digite o nome da quarta pessoa:");
        string nome4 = Console.ReadLine();
        Console.Write("Digite a idade da quarta pessoa:");
        int ida4 = int.Parse(Console.ReadLine());

        Console.Write("Digite o nome da quinta pessoa:");
        string nome5 = Console.ReadLine();
        Console.Write("Digite a idade da quinta pessoa:");
        int ida5 = int.Parse(Console.ReadLine());

        double media =  (ida1 + ida2 + ida3 + ida4 + ida5) / 5;

        string maisVelho = nome1;
        int maiorIdade = ida1;

        if (ida2 > maiorIdade)
        {
            maiorIdade = ida2;
            maisVelho = nome2;
        }
        if (ida3 > maiorIdade)
        {
            maiorIdade = ida3;
            maisVelho = nome3;
        }
        if (ida4 > maiorIdade)
        {
            maiorIdade = ida4;
            maisVelho = nome4;
        }
        if (ida5 > maiorIdade)
        {
            maiorIdade = ida5;
            maisVelho = nome5;
        }

        Console.WriteLine("A media das idades é: " + media);
        Console.WriteLine($"A pessoa mais velha é {maisVelho}, com {maiorIdade} anos.");

    }
}