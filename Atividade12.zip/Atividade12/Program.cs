﻿class Atividade12
{
    public static void Main()
    {
        string resposta = "sim";
        double areaTotal = 0;

        while (resposta.ToLower() == "sim")
        {
            Console.Write("Digite o nome do comodo:");
            string comodo = Console.ReadLine();

            Console.Write("Digite a largura do comodo:");
            double largura = double.Parse(Console.ReadLine());

            Console.Write("Digite a comprimento do comodo:");
            double comprimento = double.Parse(Console.ReadLine());

            double area = largura * comprimento;
            areaTotal += area;

            Console.WriteLine("A area do comodo " + comodo + "é igual a : " + area);
           
            Console.Write("Deseja adicionar outro cômodo? (sim/não): ");
            resposta = Console.ReadLine();
        }
        Console.WriteLine($"\nÁrea total da residência: {areaTotal:F2} m²");
    }
}