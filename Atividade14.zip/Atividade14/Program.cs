﻿using System;

class Atividade14
{
    public static void Main()
    {
        int[] vetor = new int[20];

   
        Console.WriteLine("Digite 20 números inteiros:");
        for (int i = 0; i < 20; i++)
        {
            Console.Write($"Valor {i + 1}: ");
            vetor[i] = int.Parse(Console.ReadLine());
        }

      
        Console.Write("\nDigite o valor que deseja buscar (X): ");
        int x = int.Parse(Console.ReadLine());

    
        bool encontrado = false;
        for (int i = 0; i < 20; i++)
        {
            if (vetor[i] == x)
            {
                Console.WriteLine($"\nO valor {x} foi encontrado na posição {i} do vetor.");
                encontrado = true;
                break; 
            }
        }

        if (!encontrado)
        {
            Console.WriteLine($"\nO valor {x} não foi encontrado no vetor.");
        }
    }
}
