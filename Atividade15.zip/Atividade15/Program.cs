﻿using System;

class Atividade15
{
    public static void Main()
    {
        int[] vetor = new int[40];
        int qtdPares = 0;

        Console.WriteLine("Digite 40 números inteiros:");

        for (int i = 0; i < 40; i++)
        {
            Console.Write($"Valor {i + 1}: ");
            vetor[i] = int.Parse(Console.ReadLine());

            if (vetor[i] % 2 == 0)
            {
                qtdPares++; 
            }
        }

        Console.WriteLine($"\nQuantidade de valores pares: {qtdPares}");
    }
}
