﻿using System;

class Atividade16
{
    public static void Main()
    {
        const int totalPessoas = 7;
        double[] alturas = new double[totalPessoas];
        char[] sexos = new char[totalPessoas];

        double somaAlturaMulheres = 0;
        int qtdMulheres = 0;
        int qtdHomens = 0;

        double maiorAltura = double.MinValue;
        double menorAltura = double.MaxValue;
        double somaAlturas = 0;

        for (int i = 0; i < totalPessoas; i++)
        {
            Console.Write($"Digite a altura da pessoa {i + 1}: ");
            alturas[i] = double.Parse(Console.ReadLine());

            Console.Write($"Digite o sexo da pessoa {i + 1} (m/f): ");
            sexos[i] = char.ToLower(Console.ReadLine()[0]);

        
            if (alturas[i] > maiorAltura)
                maiorAltura = alturas[i];

            if (alturas[i] < menorAltura)
                menorAltura = alturas[i];

            
            somaAlturas += alturas[i];

            if (sexos[i] == 'f')
            {
                somaAlturaMulheres += alturas[i];
                qtdMulheres++;
            }
            else if (sexos[i] == 'm')
            {
                qtdHomens++;
            }
            else
            {
                Console.WriteLine("Sexo inválido, considere como masculino para fins de contagem.");
                qtdHomens++; 
            }
        }

        double mediaMulheres = qtdMulheres > 0 ? somaAlturaMulheres / qtdMulheres : 0;
        double mediaGeral = somaAlturas / totalPessoas;

        Console.WriteLine("\nResultados:");
        Console.WriteLine($"Maior altura: {maiorAltura:F2} m");
        Console.WriteLine($"Menor altura: {menorAltura:F2} m");
        if (qtdMulheres > 0)
            Console.WriteLine($"Média de altura das mulheres: {mediaMulheres:F2} m");
        else
            Console.WriteLine("Nenhuma mulher cadastrada para calcular a média.");

        Console.WriteLine($"Média de altura do grupo: {mediaGeral:F2} m");
        Console.WriteLine($"Total de homens cadastrados: {qtdHomens}");
    }
}
